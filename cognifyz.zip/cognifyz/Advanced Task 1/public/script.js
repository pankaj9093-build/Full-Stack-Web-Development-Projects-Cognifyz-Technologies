const studentForm = document.getElementById("studentForm");
const studentList = document.getElementById("studentList");
const message = document.getElementById("message");

async function loadStudents() {
    const response = await fetch("/api/students");
    const students = await response.json();

    studentList.innerHTML = "";

    students.forEach(student => {
        const card = document.createElement("div");
        card.className = "student-card";

        card.innerHTML = `
            <div>
                <strong>${student.name}</strong><br>
                <span>${student.course}</span>
            </div>
            <button class="delete-btn" onclick="deleteStudent(${student.id})">Delete</button>
        `;

        studentList.appendChild(card);
    });
}

studentForm.addEventListener("submit", async function(event) {
    event.preventDefault();

    const name = document.getElementById("name").value.trim();
    const course = document.getElementById("course").value.trim();

    if (!name || !course) {
        message.textContent = "Both fields are required.";
        return;
    }

    await fetch("/api/students", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ name, course })
    });

    studentForm.reset();
    message.textContent = "";
    loadStudents();
});

async function deleteStudent(id) {
    await fetch(`/api/students/${id}`, {
        method: "DELETE"
    });

    loadStudents();
}

loadStudents();