const express = require("express");
const path = require("path");

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

let students = [
    { id: 1, name: "Sumit", course: "Web Development" },
    { id: 2, name: "Aman", course: "Data Science" }
];

// READ
app.get("/api/students", (req, res) => {
    res.json(students);
});

// CREATE
app.post("/api/students", (req, res) => {
    const { name, course } = req.body;

    if (!name || !course) {
        return res.status(400).json({ message: "Name and course are required" });
    }

    const newStudent = {
        id: Date.now(),
        name,
        course
    };

    students.push(newStudent);
    res.status(201).json(newStudent);
});

// DELETE
app.delete("/api/students/:id", (req, res) => {
    const id = Number(req.params.id);
    students = students.filter(student => student.id !== id);
    res.json({ message: "Student deleted" });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});