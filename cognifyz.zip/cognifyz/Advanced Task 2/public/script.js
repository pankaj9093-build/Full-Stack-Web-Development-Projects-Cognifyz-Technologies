let authToken = "";

async function registerUser() {
    const name = document.getElementById("regName").value.trim();
    const email = document.getElementById("regEmail").value.trim();
    const password = document.getElementById("regPassword").value.trim();

    if (!name || !email || !password) {
        showMessage("All register fields are required.");
        return;
    }

    const response = await fetch("/api/register", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            name: name,
            email: email,
            password: password
        })
    });

    const data = await response.json();
    showMessage(data.message);

    if (response.ok) {
        document.getElementById("regName").value = "";
        document.getElementById("regEmail").value = "";
        document.getElementById("regPassword").value = "";
    }
}

async function loginUser() {
    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value.trim();

    if (!email || !password) {
        showMessage("Email and password are required.");
        return;
    }

    const response = await fetch("/api/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            email: email,
            password: password
        })
    });

    const data = await response.json();
    showMessage(data.message);

    if (response.ok && data.token) {
        authToken = data.token;
        document.getElementById("loginEmail").value = "";
        document.getElementById("loginPassword").value = "";
    }
}

async function getProfile() {
    if (!authToken) {
        showMessage("Login first.");
        return;
    }

    const response = await fetch("/api/profile", {
        method: "GET",
        headers: {
            "Authorization": "Bearer " + authToken
        }
    });

    const data = await response.json();

    document.getElementById("profileBox").textContent =
        JSON.stringify(data, null, 2);
}

function showMessage(text) {
    document.getElementById("message").innerText = text;
}