const express = require('express');

const app = express();

app.use(express.urlencoded({ extended: true }));

app.use(express.static('public'));

app.set('view engine', 'ejs');

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

app.post('/submit', (req, res) => {

    const name = req.body.name;
    const email = req.body.email;

    res.render('result', {
        name: name,
        email: email
    });

});

app.listen(3000, () => {
    console.log('Server running');
});