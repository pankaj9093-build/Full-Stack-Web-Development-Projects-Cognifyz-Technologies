const express = require('express');

const app = express();

let users = [];

app.use(express.urlencoded({ extended: true }));

app.use(express.static('public'));

app.set('view engine', 'ejs');

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

app.post('/submit', (req, res) => {
    const name = req.body.name;
    const email = req.body.email;
    const age = req.body.age;
    const course = req.body.course;

    if (!name || !email || !age || !course) {
        return res.send("Server Validation Failed: All fields are required.");
    }

    if (age < 18) {
        return res.send("Server Validation Failed: Age must be 18 or above.");
    }

    const user = {
        name: name,
        email: email,
        age: age,
        course: course
    };

    users.push(user);

    res.render('result', {
        name: name,
        email: email,
        age: age,
        course: course,
        users: users
    });
});

app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});