let users = [];

function showPage(pageId) {
    const pages = document.querySelectorAll(".page");

    pages.forEach(function(page) {
        page.classList.remove("active");
    });

    document.getElementById(pageId).classList.add("active");
}

const form = document.getElementById("registerForm");
const password = document.getElementById("password");
const strengthText = document.getElementById("strengthText");
const strengthFill = document.getElementById("strengthFill");

password.addEventListener("input", function() {
    const value = password.value;
    let strength = 0;

    if (value.length >= 8) strength++;
    if (/[A-Z]/.test(value)) strength++;
    if (/[0-9]/.test(value)) strength++;
    if (/[@#$%&*!]/.test(value)) strength++;

    if (strength === 0) {
        strengthText.innerText = "None";
        strengthFill.style.width = "0%";
        strengthFill.style.background = "red";
    } else if (strength <= 2) {
        strengthText.innerText = "Weak";
        strengthFill.style.width = "35%";
        strengthFill.style.background = "red";
    } else if (strength === 3) {
        strengthText.innerText = "Medium";
        strengthFill.style.width = "70%";
        strengthFill.style.background = "orange";
    } else {
        strengthText.innerText = "Strong";
        strengthFill.style.width = "100%";
        strengthFill.style.background = "green";
    }
});

form.addEventListener("submit", function(event) {
    event.preventDefault();

    clearErrors();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const pass = document.getElementById("password").value;
    const confirmPass = document.getElementById("confirmPassword").value;
    const age = document.getElementById("age").value;

    let valid = true;

    if (name.length < 3) {
        document.getElementById("nameError").innerText = "Name must be at least 3 characters.";
        valid = false;
    }

    if (!email.includes("@") || !email.includes(".")) {
        document.getElementById("emailError").innerText = "Enter a valid email.";
        valid = false;
    }

    if (pass.length < 8) {
        document.getElementById("passwordError").innerText = "Password must be at least 8 characters.";
        valid = false;
    }

    if (!/[A-Z]/.test(pass) || !/[0-9]/.test(pass) || !/[@#$%&*!]/.test(pass)) {
        document.getElementById("passwordError").innerText = "Password needs uppercase, number, and special character.";
        valid = false;
    }

    if (pass !== confirmPass) {
        document.getElementById("confirmError").innerText = "Passwords do not match.";
        valid = false;
    }

    if (age < 18) {
        document.getElementById("ageError").innerText = "Age must be 18 or above.";
        valid = false;
    }

    if (!valid) return;

    const user = {
        name: name,
        email: email,
        age: age
    };

    users.push(user);
    updateUserList();

    form.reset();
    strengthText.innerText = "None";
    strengthFill.style.width = "0%";

    alert("Registration successful!");
    showPage("users");
});

function clearErrors() {
    document.getElementById("nameError").innerText = "";
    document.getElementById("emailError").innerText = "";
    document.getElementById("passwordError").innerText = "";
    document.getElementById("confirmError").innerText = "";
    document.getElementById("ageError").innerText = "";
}

function updateUserList() {
    const userList = document.getElementById("userList");
    userList.innerHTML = "";

    users.forEach(function(user) {
        const li = document.createElement("li");
        li.innerText = user.name + " | " + user.email + " | Age: " + user.age;
        userList.appendChild(li);
    });
}